const { downloadImageFromS3, resize, saveToS3 } = require("./utils");
const bucket = "moises-images-dest";
exports.handler = async (event) => {
  console.log("event.Records.length", event.Records.length);
  let filesProcessed = event.Records.map(async (record) => {
    const buf = await downloadImageFromS3(record);
    const resized = await resize(buf, 100, 100);
    const key = await saveToS3(bucket, "image", resized);
    return { key };
  });

  await Promise.all(filesProcessed);
  console.log("DONE");
  return "DONE";
};
